import { useEffect, useState, lazy, Suspense } from 'react';
import { Download, LogOut, Plus } from 'lucide-react';
import { supabase, type Product } from '../lib/supabase';

const AdminPanel = lazy(() => import('./AdminPanel'));

type ProductPageProps = {
  onLogout: () => void;
};

export default function ProductPage({ onLogout }: ProductPageProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(false);

  useEffect(() => {
    checkAdminStatus();
    fetchProducts();
  }, []);

  const checkAdminStatus = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data } = await supabase
        .from('admin_users')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      setIsAdmin(!!data);
    } catch (error) {
      console.error('Error checking admin status:', error);
    }
  };

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  const freeProducts = products.filter(p => p.type === 'free');
  const exclusiveProducts = products.filter(p => p.type === 'exclusive');

  const handleDownload = async (fileUrl: string, fileName: string) => {
    try {
      const response = await fetch(fileUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download error:', error);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    onLogout();
  };

  return (
    <div className="min-h-screen bg-[#ccc5ba] relative">
      <div className="absolute top-6 right-6 flex gap-3">
        {isAdmin && (
          <button
            onClick={() => setShowAdminPanel(true)}
            className="flex items-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-md hover:bg-amber-700 transition-colors"
          >
            <Plus size={18} />
            Add Product
          </button>
        )}
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 px-4 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-900 transition-colors"
        >
          <LogOut size={18} />
          Logout
        </button>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-serif italic text-gray-900 mb-2">
            THEEMPLATE
          </h1>
          <p className="text-sm uppercase tracking-[0.3em] text-gray-800">
            DESIGNS
          </p>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-gray-700">Loading products...</p>
          </div>
        ) : (
          <div className="space-y-16">
            <div>
              <h2 className="text-3xl md:text-4xl font-serif italic text-gray-900 mb-8 text-center">
                Free Products
              </h2>
              <div className="space-y-8">
                {freeProducts.length > 0 ? (
                  freeProducts.map((product) => (
                    <div
                      key={product.id}
                      className="bg-white rounded-lg shadow-lg p-8 md:p-12 transform transition-all hover:shadow-xl"
                    >
                      <h3 className="text-2xl md:text-3xl font-serif italic text-gray-900 mb-4">
                        {product.title}
                      </h3>
                      <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                        {product.description}
                      </p>
                      <button
                        onClick={() => handleDownload(product.file_url, product.file_name)}
                        className="flex items-center gap-3 px-8 py-4 bg-gray-900 text-white rounded-md hover:bg-gray-800 transition-colors text-lg shadow-md hover:shadow-lg"
                      >
                        <Download size={24} />
                        Download
                      </button>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-gray-600 italic">No free products available yet.</p>
                )}
              </div>
            </div>

            <div>
              <h2 className="text-3xl md:text-4xl font-serif italic text-gray-900 mb-8 text-center">
                Exclusive Products
              </h2>
              <div className="space-y-8">
                {exclusiveProducts.length > 0 ? (
                  exclusiveProducts.map((product) => (
                    <div
                      key={product.id}
                      className="bg-white rounded-lg shadow-lg p-8 md:p-12 transform transition-all hover:shadow-xl border-2 border-amber-600"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <h3 className="text-2xl md:text-3xl font-serif italic text-gray-900">
                          {product.title}
                        </h3>
                        <span className="px-3 py-1 bg-amber-600 text-white text-xs uppercase tracking-wide rounded-full">
                          Exclusive
                        </span>
                      </div>
                      <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                        {product.description}
                      </p>
                      <button
                        onClick={() => handleDownload(product.file_url, product.file_name)}
                        className="flex items-center gap-3 px-8 py-4 bg-amber-700 text-white rounded-md hover:bg-amber-800 transition-colors text-lg shadow-md hover:shadow-lg"
                      >
                        <Download size={24} />
                        Download
                      </button>
                    </div>
                  ))
                ) : (
                  <p className="text-center text-gray-600 italic">No exclusive products available yet.</p>
                )}
              </div>
            </div>
          </div>
        )}

        <div className="fixed bottom-6 right-6 max-w-xs">
          <p className="text-sm text-gray-700 italic bg-white bg-opacity-70 backdrop-blur-sm px-4 py-3 rounded-lg shadow-md">
            More free products coming soon, so stay connected with us!
          </p>
        </div>
      </div>

      {showAdminPanel && (
        <Suspense fallback={<div>Loading...</div>}>
          <AdminPanel
            onClose={() => setShowAdminPanel(false)}
            onProductAdded={() => {
              fetchProducts();
              setShowAdminPanel(false);
            }}
          />
        </Suspense>
      )}
    </div>
  );
}
