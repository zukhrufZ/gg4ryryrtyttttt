import { useState } from 'react';
import AuthModal from './AuthModal';

type LandingPageProps = {
  onAuthSuccess: () => void;
};

export default function LandingPage({ onAuthSuccess }: LandingPageProps) {
  const [showModal, setShowModal] = useState(false);
  const [modalMode, setModalMode] = useState<'login' | 'signup'>('login');

  const handleOpenModal = (mode: 'login' | 'signup') => {
    setModalMode(mode);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    onAuthSuccess();
  };

  return (
    <div className="min-h-screen bg-[#ccc5ba] flex flex-col items-center justify-center px-4">
      <div className="text-center max-w-3xl">
        <h1 className="text-5xl md:text-7xl font-serif italic text-gray-900 mb-4 tracking-wide">
          THEEMPLATE
        </h1>
        <p className="text-sm md:text-base uppercase tracking-[0.3em] text-gray-800 mb-16">
          DESIGNS
        </p>

        <h2 className="text-2xl md:text-4xl text-gray-800 mb-12 font-light leading-relaxed">
          Download productivity products for free
        </h2>

        <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
          <button
            onClick={() => handleOpenModal('signup')}
            className="px-12 py-4 bg-gray-900 text-white text-lg rounded-md hover:bg-gray-800 transition-all duration-300 shadow-lg hover:shadow-xl min-w-[200px]"
          >
            Sign Up
          </button>
          <button
            onClick={() => handleOpenModal('login')}
            className="px-12 py-4 bg-white text-gray-900 text-lg rounded-md hover:bg-gray-100 transition-all duration-300 border-2 border-gray-300 shadow-lg hover:shadow-xl min-w-[200px]"
          >
            Login
          </button>
        </div>

        <div className="mt-24 text-center">
          <p className="text-sm text-gray-600 italic max-w-md mx-auto">
            "Design is more than what you see; it's the feeling your brand leaves behind."
          </p>
        </div>
      </div>

      <AuthModal
        isOpen={showModal}
        onClose={handleCloseModal}
        mode={modalMode}
      />
    </div>
  );
}
