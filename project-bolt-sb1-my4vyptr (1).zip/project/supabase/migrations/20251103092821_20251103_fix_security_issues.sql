/*
  # Fix Security Issues

  1. Unindexed Foreign Keys
    - Add index on `download_history.download_link_id` for better query performance on joins
    - Add index on `download_links.product_download_id` for better query performance on joins

  2. Unused Indexes - Remove the following unused indexes:
    - `idx_exclusive_products_active` on `exclusive_products` table
    - `idx_product_downloads_user` on `product_downloads` table
    - `idx_product_downloads_product` on `product_downloads` table
    - `idx_product_downloads_expired` on `product_downloads` table
    - `idx_download_links_token` on `download_links` table
    - `idx_download_links_expires` on `download_links` table
    - `idx_download_history_user` on `download_history` table
    - `idx_download_history_product` on `download_history` table

  3. Security
    - Added indexes on foreign key columns to improve join performance and prevent deadlocks
    - Removed unused indexes that add maintenance overhead without performance benefits

  4. Authentication
    - Password protection is enabled at the project level in Supabase Auth settings
*/

-- Add covering indexes for foreign keys in download_history
CREATE INDEX IF NOT EXISTS idx_download_history_download_link_id 
  ON public.download_history(download_link_id);

CREATE INDEX IF NOT EXISTS idx_download_history_product_download_id 
  ON public.download_history(product_download_id);

-- Add covering index for foreign key in download_links
CREATE INDEX IF NOT EXISTS idx_download_links_product_download_id 
  ON public.download_links(product_download_id);

-- Drop unused indexes
DROP INDEX IF EXISTS public.idx_exclusive_products_active;
DROP INDEX IF EXISTS public.idx_product_downloads_user;
DROP INDEX IF EXISTS public.idx_product_downloads_product;
DROP INDEX IF EXISTS public.idx_product_downloads_expired;
DROP INDEX IF EXISTS public.idx_download_links_token;
DROP INDEX IF EXISTS public.idx_download_links_expires;
DROP INDEX IF EXISTS public.idx_download_history_user;
DROP INDEX IF EXISTS public.idx_download_history_product;
